# play-java-jpa-example

This project demonstrates how to create a simple database application with Play, using JPA.

Please see the Play documentation for more details:

* https://www.playframework.com/documentation/latest/JavaJPA
* https://www.playframework.com/documentation/latest/ThreadPools
* https://www.playframework.com/documentation/latest/JavaAsync
